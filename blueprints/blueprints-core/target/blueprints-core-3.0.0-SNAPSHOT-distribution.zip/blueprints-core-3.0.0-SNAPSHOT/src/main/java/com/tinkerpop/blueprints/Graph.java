package com.tinkerpop.blueprints;

/**
 * A Graph is a container object for a collection of vertices and a collection edges.
 *
 * @author Marko A. Rodriguez (http://markorodriguez.com)
 */
public interface Graph {
}
